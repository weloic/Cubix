import lejos.hardware.Sound;
import lejos.hardware.lcd.LCD;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.utility.Delay;

@SuppressWarnings("javadoc")
public class Main {

	public static void main(String[] args) {
		
		EV3ColorSensor sensor = new EV3ColorSensor(SensorPort.S1);
		Sound.beep();

	}

}
